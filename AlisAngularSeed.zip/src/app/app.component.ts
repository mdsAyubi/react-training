import { Component } from '@angular/core';

@Component({
  selector: 'render-me',
  template: `<h1 class="alert-success">Welcome to {{info}}</h1>`,
})
export class AppComponent  { info = 'AngularJS'; }
