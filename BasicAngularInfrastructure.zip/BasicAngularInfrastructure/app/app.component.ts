import {Component} from 'angular2/core';

@Component({
    selector: 'my-app',
    template: '<h1>Start With angular2 </h1>'
})
export class AppComponent { }